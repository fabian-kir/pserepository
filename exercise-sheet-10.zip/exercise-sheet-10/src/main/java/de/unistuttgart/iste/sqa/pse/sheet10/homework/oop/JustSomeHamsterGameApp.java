package de.unistuttgart.iste.sqa.pse.sheet10.homework.oop;

/**
 * Just some app to start some game.
 *
 * @author your name
 */
public final class JustSomeHamsterGameApp {
	public static void main(String[] args) {
		final JustSomeHamsterGame game = new JustSomeHamsterGame();
		game.doRun();
	}
}
